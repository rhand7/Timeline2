//: Playground - noun: a place where people can play

import UIKit

struct ChangeReturned {
    let dollar: Int
    let quarter: Int
    let dime: Int
    let nickel: Int
    let penny: Int
}

func getChangeFrom(money: Double) -> ChangeReturned {
    var dollar = 0
    var quarter = 0
    var dime = 0
    var nickel = 0
    var penny = 0
    
    var moneyLeft = Int(money * 100)
    
    dollar = Int(moneyLeft / 100)
    moneyLeft = moneyLeft - (dollar * 100)
    quarter = Int(moneyLeft / 25)
    moneyLeft = moneyLeft - (quarter * 25)
    dime = Int(moneyLeft / 10)
    moneyLeft = moneyLeft - (dime * 10)
    nickel = Int(moneyLeft / 5)
    moneyLeft = moneyLeft - (nickel * 5)
    penny = Int(moneyLeft / 1)
    
    
    return ChangeReturned(dollar: dollar, quarter: quarter, dime: dime, nickel: nickel, penny: penny)
}

let change = getChangeFrom(money: 2.23)

print("Dollars: \(change.dollar), Quarters: \(change.quarter), Dimes: \(change.dime), Nickels: \(change.nickel), Pennies: \(change.penny)")

func changeFromPurchase(cost: Double, amount: Double) -> ChangeReturned {
    let change = amount - cost

    let changeReturned = getChangeFrom(money: change)
    return changeReturned
}

let changeReturned = changeFromPurchase(cost: 2.15, amount: 5.00)

print("Dollars: \(changeReturned.dollar), Quarters: \(changeReturned.quarter), Dimes: \(changeReturned.dime), Nickels: \(changeReturned.nickel), Pennies: \(changeReturned.penny)")

let intArray = [15,13,31,131,65,17]

func ownFilter<T>(source: [T], closure: (T) -> Bool) -> [T] {
    var result = [T]()
    for i in source {
        if closure(i) {
            result.append(i)
        }
    }
    return result
}

let filteredArray = intArray.filter { $0 > 30 }
let ownFilteredArray = ownFilter(source: intArray) { intFromArray in
    intFromArray > 30
}

print(filteredArray)
print(ownFilteredArray)





























