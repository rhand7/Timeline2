//
//  ItemListTableViewController.swift
//  Unit 2 Assessment - ShoppingList
//
//  Created by handje on 4/7/17.
//  Copyright © 2017 Rob Hand. All rights reserved.
//

import UIKit

class ItemListTableViewController: UITableViewController, ButtonTableViewCellDelegate {  //3. conforms to BTbVCellDelegate
    
    var items: [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.reloadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    
    // MARK: - TableViewDataSource/Delegate
    
    //#RowsInSection
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ItemController.sharedController.items.count
    }
    
    //cellForRowAt
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath) as? ButtonTableViewCell
            else { return UITableViewCell() }                                         //6. add delegate and update cell
        
        let item = ItemController.sharedController.items[indexPath.row]
        
        cell.delegate = self
        cell.item = item                                        //gets item from BTbVCell
        cell.nameLabel?.text = item.name
        
        return cell
    }
    
    
    // slide to delete
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    
    //ButtonTableViewCellDelegate
    func buttonCellButtonTapped(sender: ButtonTableViewCell) {                       //3. add protocol
        guard let indexPath = tableView.indexPath(for: sender) else { return }       //5. implement cell delegate
        let item = self.items[indexPath.row]
        ItemController.sharedController.toggleIsCompleteFor(item: item)
        tableView.reloadRows(at: [indexPath], with: .automatic)
        
    }
    
    //MARK: IB Outlet - AlertController needs to update nameLabel
    
    @IBOutlet weak var nameLabel: UILabel!
    
    //MARK: IB Action - Add List Item Button
    
    var item: Item?
    
    @IBAction func addButtonTapped(_ sender: Any) {
        setUpAlterController()
    }
    
    
    //MARK: AlertController
    
    func setUpAlterController () {
        
        let alert = UIAlertController(title: "Add Item", message: "Add an item to your list", preferredStyle: .alert)
        
        alert.addTextField { (textField: UITextField) in
            textField.placeholder = "List Item"
        }
        self.present(alert, animated: true, completion: nil)
        
        let itemTextField: UITextField?
        
        let addItem = UIAlertAction(title: "Add", style: .default) { _ in
            guard let textField = itemTextField,
                let text = textField.text, !text.isEmpty else { return }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
        }
        alert.addAction(cancelAction)
        alert.addAction(addItem)
    }
}

